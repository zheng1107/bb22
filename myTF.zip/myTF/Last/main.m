//
//  main.m
//  Last
//
//  Created by Mr郑 on 2017/6/27.
//  Copyright © 2017年 Mr郑. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
